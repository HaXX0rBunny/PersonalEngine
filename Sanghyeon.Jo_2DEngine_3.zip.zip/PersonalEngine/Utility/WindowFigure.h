#pragma once
#include "GLHeader.h"
#define Window_width 1600
#define Window_height 800
#define EngineTitle "Biginner"
