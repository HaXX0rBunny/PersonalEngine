#pragma once
#include <string>
#include <iostream>
#include "json.hpp"
#include <fstream>
#include "../GameObjectManager/GameObjectManager.h"


bool IsDataModified(const std::string& filePath);
