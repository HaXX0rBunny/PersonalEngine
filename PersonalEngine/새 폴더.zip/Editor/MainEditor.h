#pragma once
class MainEditor {
	void TopBar();
	char buffer[100] = { 0 };
};