#pragma once
#include "BaseLevel.h"
namespace Levels
{

	class TempLevel : public GSM::BaseLevel
	{



	};
}
