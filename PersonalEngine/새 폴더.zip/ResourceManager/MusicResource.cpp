#include "MusicResource.h"


void MusicResource::Load(const std::string& filename)
{
}

void MusicResource::Unload()
{
}

void* MusicResource::GetData() const
{
    return nullptr;
}
